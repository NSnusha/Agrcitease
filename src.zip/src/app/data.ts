export class Data {
    crop:String;
    counts:String;
}
