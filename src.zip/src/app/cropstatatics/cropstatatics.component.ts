import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cropstatatics',
  templateUrl: './cropstatatics.component.html',
  styleUrls: ['./cropstatatics.component.css']
})
export class CropstataticsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
