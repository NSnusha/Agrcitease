import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about1',
  templateUrl: './about1.component.html',
  styleUrls: ['./about1.component.css','./nicepage.css','./Page-1.css','./Page-2.css'],
  

})
export class About1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
