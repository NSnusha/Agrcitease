import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allforms',
  templateUrl: './allforms.component.html',
  styleUrls: ['./allforms.component.css']
})
export class AllformsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
