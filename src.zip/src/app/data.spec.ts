import { Data } from './data';

describe('Data', () => {
  it('should create an instance', () => {
    expect(new Data()).toBeTruthy();
  });
});
