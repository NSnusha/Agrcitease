import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showfarms',
  templateUrl: './showfarms.component.html',
  styleUrls: ['./showfarms.component.css']
})
export class ShowfarmsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
